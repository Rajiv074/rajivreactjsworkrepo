import React , {Component} from 'react';
import logo from './logo.svg';
import './App.css';
const INITIAL_STATE ={
  List:[1,2,3],
  value: '',
} ;
const UPDATE_STATE ={
  List:[1,2,3],
  value: '',
} ;
class App extends Component {
  constructor(props){
    super(props);
    this.state = INITIAL_STATE
  }
 addItem = (e) =>{
debugger;
const new_value= this.state.value;
const newList = this.state.List.concat(new_value);
this.setState({List:newList});
this.state.value = '';
}
onchange = (e) => {
debugger;
this.setState({value:e.target.value})
}

deleteItem = (index,e)=>{
  debugger;
  let List = Object.assign([],this.state.List);
  List.splice(index,1);
  this.setState({List:List});
}

  render(){
  return (
    <div className="App">
       <ul>
         {
           this.state.List.map((val,index)=>{
             return(
               <li key = {val}>{val} 
               <input type = "button" value = "X" onClick = {this.deleteItem.bind(this,index)}/>
               </li>
             )
           })
         }
       </ul>
       <input type = "button" value = "Add new Item " onClick = {this.addItem.bind(this)} disabled = {!this.state.value}/>
       <input type = "text"  value = {this.state.value} onChange = {this.onchange.bind(this)}/>
       <UpdateItem/>
    </div>
  );
}
}
class UpdateItem extends Component{
  constructor(props){
    super(props);
    this.state = UPDATE_STATE
    var count = 0;
  }
Incage = (index) =>{
debugger;
    this.setState(state=>{
      const List =  state.List.map((item,j)=>{
        if(j===index){
          return parseInt(item)+1;
        }else{
          return item;
        }
      });
      return {
        List,
      }
    })
  }
  render(){
    debugger;
    return(
      <div>
        <ul>
          {
            this.state.List.map((item,index)=>{
              return(
                <li key = {item}>the person is {item} old 
                <input type = "button" value = "Make me Older" onClick = {this.Incage.bind(this,index)}/>
                </li>
              )
            })
          }
        </ul>
      </div>
    )
  }
}
export default App;

