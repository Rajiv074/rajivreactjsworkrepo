import React , {Component} from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      todos:[],text:''
    };
    this.removeTodo = this.removeTodo.bind(this);
  }

  updateval = (pthis) =>{
    debugger
    this.setState({text:pthis.target.value});
  }
  addTodo = (pthis) =>{
    debugger;
  pthis.preventDefault();
  this.setState({ 
    todos: [...this.state.todos,this.state.text],
    text: ''
  });
/*
  const new_text = this.state.text;
  const newToDo = this.state.todos.concat(new_text)
  this.setState({todos:newToDo});
  this.setState({text:''});
  */
  }
  removeTodo = (index,i)=>{
debugger;
let todos = Object.assign([],this.state.todos)
todos.splice(index,1)
this.setState({todos:todos})
  }
  render(){
  return (
    <div className="App"> 
    <form onSubmit = {this.addTodo.bind(this)}>
    <input type  = "text" placeholder = "Add ToDo" value = {this.state.text} onChange = {this.updateval.bind(this)}/>
    <button type = "submit" disabled = {!this.state.text}>Add ToDo</button>
    </form>
    <TodoList todos = {this.state.todos} removeTodo = {this.removeTodo}/>
    </div>
  );
}
}

class TodoList extends React.Component {

  removeItem(item, i) {
    debugger;
      this.props.removeTodo(item, i);
  }

  render() {
      return(
          <ul>
              { this.props.todos.map((val,i) => {
                  return <li onClick={() => { this.removeItem(val, i)}} key={i}>{ val }</li>
              })}
          </ul>
      );
  }
}

export default App;
